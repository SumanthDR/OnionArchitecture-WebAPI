﻿using App.Model.Data;
using App.Model.RequestModel.Cards;

namespace App.Service.IService
{
    public interface ICardsService
    {
        /// <summary>
        /// AddCards
        /// </summary>
        /// <param name="addCardsRequestModel"></param>
        /// <returns>Cards</returns>
        Task<Cards> AddCardsAsync(AddCardsRequestModel addCardsRequestModel);
        /// <summary>
        /// GetListOfCards
        /// </summary>
        /// <returns>List of Cards</returns>
        Task<List<Cards>> GetListOfCardsAsync();
        /// <summary>
        /// Get Card By Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<Cards> GetCardByIdAsync(int id);
        /// <summary>
        /// Delete Card by Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<bool> DeleteCardByIdAsync(int id);
        /// <summary>
        /// Update Card Details
        /// </summary>
        /// <param name="updateCardsRequestModel"></param>
        /// <returns></returns>
        Task<Cards> UpdateCardDetailsAsync(UpdateCardsRequestModel updateCardsRequestModel);
    }
}
