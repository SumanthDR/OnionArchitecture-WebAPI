﻿using App.Model;
using App.Model.Data;
using App.Model.RequestModel.Cards;
using App.Repository.IRepository;
using Microsoft.EntityFrameworkCore;

namespace App.Repository.Repository
{
    public class CardsRespository : ICardsRespository
    {        
        private readonly AppDbContext _appDbContext;

        public CardsRespository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;            
        }

        public async Task<Cards> AddCardsAsync(AddCardsRequestModel addCardsRequestModel)
        {
            Cards cards = new Cards
            {
                Name = addCardsRequestModel.Name,
                Description = addCardsRequestModel.Description,
                IsActive = addCardsRequestModel.IsActive,
                CreatedDateTime = DateTime.Now,
            };

            _appDbContext.Cards.Add(cards);
            await _appDbContext.SaveChangesAsync();

            return cards;
        }

        public async Task<List<Cards>> GetListOfCardsAsync()
        {
            var result = await _appDbContext.Cards.Where(x => x.IsActive).ToListAsync();
            return result;
        }

        public async Task<Cards> GetCardByIdAsync(int id)
        {
            var result = await _appDbContext.Cards.FirstOrDefaultAsync(x => x.IsActive && x.Id == id);
            return result;
        }

        public async Task<bool> DeleteCardByIdAsync(int id)
        {
            var result = await GetCardByIdAsync(id);
            if(result != null)
            {
                result.IsActive = false;

                _appDbContext.Cards.Update(result);
                await _appDbContext.SaveChangesAsync();

                return true;
            }
            return false;
        }

        public async Task<Cards> UpdateCardDetailsAsync(UpdateCardsRequestModel updateCardsRequestModel)
        {
            var result = await GetCardByIdAsync(updateCardsRequestModel.Id);
            
            if(result != null) 
            {
                result.Name = updateCardsRequestModel.Name;
                result.Description = updateCardsRequestModel.Description;

                _appDbContext.Cards.Update(result);
                await _appDbContext.SaveChangesAsync();
            }
            return result;
        }
    }
}
