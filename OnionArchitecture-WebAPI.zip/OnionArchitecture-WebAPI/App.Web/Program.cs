using App.Model;
using App.Repository.IRepository;
using App.Repository.Repository;
using App.Service.IService;
using App.Service.Service;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddDbContext<AppDbContext>(options => 
options.UseSqlServer(builder.Configuration.GetConnectionString("defaultDbConnection")));

builder.Services.AddScoped<ICardsRespository, CardsRespository>();
builder.Services.AddScoped<ICardsService, CardsService>();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

//Configure the HTTP request pipeline.

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
